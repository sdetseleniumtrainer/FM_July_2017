package com.fanniemae.draft;

import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import com.fanniemae.utilities.ShootMail;
import com.fanniemae.utilities.TestConfig;


public class TestMail {

	public static void main(String[] args) throws UnknownHostException, AddressException, MessagingException {

		ShootMail mail = new ShootMail();
		String messageBody = "http://" + InetAddress.getLocalHost().getHostAddress()
				+ ":8888/job/End2EndMvnJnk/Extent_HTML_Report/";
		System.out.println(messageBody);
		
		mail.sendMail(TestConfig.server, TestConfig.from, TestConfig.to, TestConfig.subject, messageBody);

	}

}

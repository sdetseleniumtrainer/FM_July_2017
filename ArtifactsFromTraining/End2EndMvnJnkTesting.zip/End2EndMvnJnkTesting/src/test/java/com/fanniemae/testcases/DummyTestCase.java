package com.fanniemae.testcases;

import java.io.IOException;

import org.testng.annotations.Test;

import com.fanniemae.base.TestBase;
import com.fanniemae.utilities.TestUtil;

public class DummyTestCase extends TestBase {
	
	
	@Test
	public void tc_LoginTestCase() throws IOException{
		
		TestUtil.captureScreenshot();
	}
	
	
	@Test(enabled=false)
    public void tc_NewAccountTestCase(){
		
		
	}
	
	
	
	

}

package com.fanniemae.utilities;

public class TestConfig{


	
	public static String server="smtp.gmail.com";
	public static String from = "sdet.trainer@gmail.com";
	public static String password = "Passw0rd!@#";
	public static String[] to ={"sdet.agile@outlook.com","irfan@sdettraining.com"};
	public static String subject = "Fannie Project Report";
	
	public static String messageBody ="TestMessage";
	public static String attachmentPath="c:\\reports\\screenshot\\2017_10_3_14_49_9.jpg";
	public static String attachmentName="error.jpg";
	
	
	
	//SQL DATABASE DETAILS	
	public static String driver="net.sourceforge.jtds.jdbc.Driver"; 
	public static String dbConnectionUrl="jdbc:jtds:sqlserver://142.36.25.22;DatabaseName=testdb"; 
	public static String dbUserName="sa"; 
	public static String dbPassword=""; 
	
	
	//MYSQL DATABASE DETAILS
	public static String mysqldriver="com.mysql.jdbc.Driver";
	public static String mysqluserName = "root";
	public static String mysqlpassword = "hexaware";
	public static String mysqlurl = "jdbc:mysql://localhost:3306/acs";
	
	
	
	
	
	
	
	
	
}

package com.fannie.step_definitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class NewUserRegistration_step_definition {
	
	@Given("^user is on new account page$")
	public void user_is_on_new_account_page() throws Throwable {
	   
	}

	@When("^user enters \"([^\"]*)\" in firstname field$")
	public void user_enters_in_firstname_field(String arg1) throws Throwable {
	    
	}

	@When("^user enters \"([^\"]*)\" in lastname field$")
	public void user_enters_in_lastname_field(String arg1) throws Throwable {
	   
	}

	@When("^user selects \"([^\"]*)\" as gender$")
	public void user_selects_as_gender(String arg1) throws Throwable {
	    
	}

	@When("^user enters \"([^\"]*)\" in verifypassword field$")
	public void user_enters_in_verifypassword_field(String arg1) throws Throwable {
	   
	}

	@When("^user enters \"([^\"]*)\" in homephone field$")
	public void user_enters_in_homephone_field(String arg1) throws Throwable {
	    
	}

	@When("^user enters \"([^\"]*)\" in cellphone field$")
	public void user_enters_in_cellphone_field(String arg1) throws Throwable {
	   
	}

	@When("^user selects \"([^\"]*)\" from country field$")
	public void user_selects_from_country_field(String arg1) throws Throwable {
	  
	}

	@When("^user checks \"([^\"]*)\" in subscription field$")
	public void user_checks_in_subscription_field(String arg1) throws Throwable {
	   
	}

	@When("^user clicks on Submit button$")
	public void user_clicks_on_Submit_button() throws Throwable {
	    
	}

	@Then("^user is successfully registered$")
	public void user_is_successfully_registered() throws Throwable {
	    
	}

}

package com.fannie.runners;

public class CucuberTestRunnerClass {

}
